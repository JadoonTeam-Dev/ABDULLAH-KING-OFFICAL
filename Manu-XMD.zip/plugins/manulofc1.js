const config = require('../config')
const {cmd , commands} = require('../command')
const fg = require('api-dylux')
const yts = require('yt-search')
const dl = require('@bochilteam/scraper')  
const ytdl = require('ytdl-core')
const l = console.log
const fs = require('fs-extra')
var {subsearch , subdl }  = require('@sl-code-lords/si-subdl')
const Esana = require('@sl-code-lords/esana-news');
var api = new Esana()
var videotime = 60000 // 1000 min
const { getBuffer, getGroupAdmins, getRandom, h2k, isUrl, Json, runtime, sleep, fetchJson} = require('../lib/functions')
cmd({
    pattern: "yts",
    alias: ["ytsearch"],
    use: '.yts lelena',
    react: "🔎",
    desc: "Search and get details from youtube.",
    category: "search",
    filename: __filename

},

async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
if (!q) return reply('*Please give me words to search*')
try {
let yts = require("yt-search")
var arama = await yts(q);
} catch(e) {
    l(e)
return await conn.sendMessage(from , { text: '*Error !!*' }, { quoted: mek } )
}
var mesaj = '';
arama.all.map((video) => {
mesaj += ' *🖲️' + video.title + '*\n🔗 ' + video.url + '\n\n'
});
await conn.sendMessage(from , { text:  mesaj }, { quoted: mek } )
} catch (e) {
    l(e)
  reply('*Error !!*')
}
})

//===========song-download===========

cmd({
    pattern: "song",
    react: "🎵",
    desc: "downlod song",
    category: "downlod",
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
if(!q) return reply("❌Please give me url or titel")
const search = await yts(q)
const deta = search.videos[0];
const url = deta.url 

let desc= `
*•.¸♡ MANU-MD AUDIO-DOWNLOADER🎶 ♡¸.•*
|__________________________
| ❤️‍🩹title : ${deta.title}
| ❤️‍🩹description : ${deta.description}
| ❤️‍🩹time : ${deta.timestamp}
| ❤️‍🩹ago : ${deta.ago}
| ❤️‍🩹views : ${deta.views}
|__________________________

POWERED by *✨MR CYBER MANUL OFFICIAL 💗*

`
await conn.sendMessage(from,{image :{ url: deta.thumbnail},caption:desc},{quoted:mek});

//downlod audio+ document

let down = await fg.yta(url)
let downloadUrl = down.dl_url

//send audio message 
await conn.sendMessage(from,{audio:{url:downloadUrl},mimetype:"audio/mpeg",caption :"*©ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴍᴀɴᴜʟ ᴏꜰꜰɪᴄɪᴀʟ*"},{quoted:mek})
await conn.sendMessage(from,{document:{url:downloadUrl},mimetype:"audio/mpeg",fileName:deta.title + ".mp3" ,caption :"*©ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴍᴀɴᴜʟ ᴏꜰꜰɪᴄɪᴀʟ*"},{quoted:mek})

  

}catch(e){
console.log(e)
reply(`${e}`)
}
})

//========video dl=======

cmd({
    pattern: "video",
    react: "🎬",
    desc: "downlod video",
    category: "downlod",
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
if(!q) return reply("❌Please give me url or title")
const search = await yts(q)
const deta = search.videos[0];
const url = deta.url 

let desc= `
*•.¸♡ MANU-MD VIDEO-DOWNLOADER📽️ ♡¸.•*
|__________________________
| ❤️‍🩹title : ${deta.title}
| ❤️‍🩹description : ${deta.description}
| ❤️‍🩹time : ${deta.timestamp}
| ❤️‍🩹ago : ${deta.ago}
| ❤️‍🩹views : ${deta.views}
|__________________________

POWERED by *✨MR CYBER MANUL OFFICIAL 💗*

`

await conn.sendMessage(from,{image :{ url: deta.thumbnail},caption:desc},{quoted:mek});

//downlod video + document 

let down = await fg.ytv(url)
let downloadUrl = down.dl_url

//send video  message 
await conn.sendMessage(from,{video:{url:downloadUrl},mimetype:"video/mp4",caption :"*©ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴍᴀɴᴜʟ ᴏꜰꜰɪᴄɪᴀʟ*"},{quoted:mek})
await conn.sendMessage(from,{document:{url:downloadUrl},mimetype:"video/mp4",fileName:deta.title + ".mp4",caption :"*©ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴍᴀɴᴜʟ ᴏꜰꜰɪᴄɪᴀʟ*"},{quoted:mek})


}catch(e){
console.log(e)
reply(`${e}`)
}
})
//=========song2======
cmd({
    pattern: "song2",
    alias: ["ytsong"],
    use: '.song lelena',
    react: "🎧",
    desc: "Search & download yt song.",
    category: "download",
    filename: __filename
},

async(conn, mek, m,{from, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
if (!q) return reply('*Please give me quary to download*')
let yts = require("yt-search")
let search = await yts(q)
let anu = search.videos[0]
const cap = `*⬇️MANU-MD AUDIO DOWNLOADER⬇️*
*🫧Title:* ${anu.title}
*❄️Views:* ${anu.views}
*🎯Duration:* ${anu.timestamp}

*🪄Url:* ${anu.url}

*ᴍᴀɴᴜ ᴍᴅ ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ*`
await conn.sendMessage(from, { image: { url: anu.thumbnail }, caption: cap}, { quoted: mek })
let infoYt = await ytdl.getInfo(anu.url);
if (infoYt.videoDetails.lengthSeconds >= videotime) {
    reply("❌ ```Unable to upload this file according to your Platform Upload Size```❗ \n\n *_Please update your MAX_SIZE var on the Upload Size on your platform_* ❗🧑‍💻");
    return;
}
let titleYt = infoYt.videoDetails.title;
let randomName = getRandom(".mp3");
const stream = ytdl(anu.url, {
        filter: (info) => info.audioBitrate == 160 || info.audioBitrate == 128,
    })
    .pipe(fs.createWriteStream(`./${randomName}`));
await new Promise((resolve, reject) => {
    stream.on("error", reject);
    stream.on("finish", resolve);
});

let stats = fs.statSync(`./${randomName}`);
let fileSizeInBytes = stats.size;
let fileSizeInMegabytes = fileSizeInBytes / (1024 * 1024);
    let sendaE = await conn.sendMessage(from, { document : fs.readFileSync(`./${randomName}`)  ,caption: anu.title ,mimetype: 'audio/mpeg', fileName: `${titleYt}.mp3` }, { quoted: mek })
    await conn.sendMessage(from, { react: { text: '📁', key: sendaE.key }})
await conn.sendMessage(from, { react: { text: '✔️', key: mek.key }})
return fs.unlinkSync(`./${randomName}`);
fs.unlinkSync(`./${randomName}`);
} catch (e) {
  reply("🚫 *Request incompleted !* ```EROR:YTDL```\n\n 🔄 *_Solution - Try Again Little Movement_* 🧑‍💻")
  console.log(e)
}
})

//=========viddl2======

cmd({
    pattern: "video2",
    alias: ["ytvideo"],
    use: '.video lelena',
    react: "📽️",
    desc: "Search & download yt videos.",
    category: "download",
    filename: __filename

},

async(conn, mek, m,{from, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
if (!q) return reply('*Please give me quary to download*')
let yts = require("yt-search")
let search = await yts(q)
let anu = search.videos[0]
const cap = `*⬇️MANU-MD VIDEO DOWNLOADER⬇️*
*🫧Title:* ${anu.title}
*❄️Views:* ${anu.views}
*🎯Duration:* ${anu.timestamp}

*🪄Url:* ${anu.url}

*ᴍᴀɴᴜ ᴍᴅ ᴍᴜʟᴛɪ ᴅᴇᴠɪᴄᴇ*`
await conn.sendMessage(from, { image: { url: anu.thumbnail }, caption: cap}, { quoted: mek })
const yt = await dl.youtubedl(anu.url).catch(async () => await dl.youtubedlv2(anu.url)) 
const yt2 = await dl.youtubedlv2(anu.url)
let senda = await conn.sendMessage(from, { video: {url: await yt.video['360p'].download() }, caption: ''}, { quoted: mek })  
await conn.sendMessage(from, { react: { text: '🎥', key: senda.key }})

if (yt2.video['720p'].fileSizeH.includes('MB') && yt2.video['720p'].fileSizeH.replace(' MB','') >= config.MAX_SIZE) return await conn.sendMessage(from, { text: '*This video too big !!*' }, { quoted: mek });
if (yt2.video['720p'].fileSizeH.includes('GB')) return await conn.sendMessage(from, { text: '*This video too big !!*' }, { quoted: mek });
let senda1 = await conn.sendMessage(from, { video: {url: await yt.video['720p'].download() }, caption: ''}, { quoted: mek })  
await conn.sendMessage(from, { react: { text: '🎥', key: senda1.key }})
} catch (e) {
  reply("*Not Found !*")
  console.log(e)
}
})

//=====Ai=====

cmd({
    pattern: "ai",
    react: "🧚",
    desc: "ai chat",
    category: "main",
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
let data = await fetchJson(`https://chatgptforprabath-md.vercel.app/api/gptv1?q=${q}`)
return reply(`${data.data}`)

}catch(e){
console.log(e)
reply(`${e}`)
}
})

//=========Alive======

cmd({
    pattern: "alive",
    desc: "Check bot online or no.",
    category: "main",
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
const voice = {
    alive: 'media/media_alive.mp3'
}

await conn.sendMessage(from, { audio: { url: voice.alive }, mimetype: 'audio/mp4', ptt: true }, { quoted: mek })

return await conn.sendMessage(from,{image: {url: config.ALIVE_IMG},caption: config.ALIVE_MSG},{quoted: mek})
}catch(e){
console.log(e)
reply(`${e}`)
}
})

//============ping=======

cmd({
    pattern: "ping",
    react: "📟",
    alias: ["speed"],
    desc: "Check bot\'s ping",
    category: "main",
    use: '.ping',
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
var inital = new Date().getTime();
let ping = await conn.sendMessage(from , { text: '```Pinging To index.js!!!```'  }, { quoted: mek } )
var final = new Date().getTime();
return await conn.edit(ping, '*Pong*\n *' + (final - inital) + ' ms* ' )
} catch (e) {
reply(`${e}`)
console.log(e)
}
})

//===========menu========
cmd({
    pattern: "menu",
    react: "🧚‍♀️",
    alias: ["panel"],
    desc: "Get bot\'s command list.",
    category: "main",
    use: '.menu',
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
const voice = {
    menu: 'media/media_menu.mp3'
}

let tex = `
> *👋.ʜɪ* ${pushname},
> ɪ ᴀᴍ ᴀɴ ᴀᴜᴛᴏᴍᴀᴛᴇᴅ ꜱʏꜱᴛᴇᴍ *(ᴡʜᴀᴛꜱᴀᴘᴘ ʙᴏᴛ)* ᴛʜᴀᴛ ᴄᴀɴ ʜᴇʟᴘ ᴛᴏ ᴅᴏ ꜱᴏᴍᴇᴛʜɪɴɢ, ꜱᴇᴀʀᴄʜ ᴀɴᴅ ɢᴇᴛ ᴅᴀᴛᴀ / ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ ᴏɴʟʏ ᴛʜʀᴏᴜɢʜ *ᴡʜᴀᴛꜱᴀᴘᴘ.🪀*

🧚‍♀️◦ *ɴᴀᴍᴇ ʙᴏᴛ* : ᴍᴀɴᴜ-ᴍᴅ⚡
🧚‍♀️◦ *ᴄʀᴇᴀᴛᴏʀ* : ᴍᴀɴᴜʟ ᴏꜰꜰɪᴄɪᴀʟ⚡
🧚‍♀️◦ *ʙᴏᴛ ᴜꜱᴇʀ* :${pushname}⚡
🧚‍♀️◦ *ᴜᴘᴛɪᴍᴇ* : ${runtime(process.uptime())}⚡
🧚‍♀️◦ *ᴠᴇʀsɪᴏɴs* : 7.0.0 (ᴀᴅᴅᴇᴅ ʜɪᴅᴅᴇɴ ғᴇᴀᴜᴛᴜʀᴇs)⚡
🧚‍♀️◦ *ᴛʏᴘᴇ sᴄʀɪᴘᴛ* : ᴘʟᴜɢɪɴs⚡
🧚‍♀️◦ *ᴊᴏɪɴ ᴍʏ ɢʀᴏᴜᴘ* :  https://whatsapp.com/channel/0029VaN1XMn2ZjCsu9eZQP3R ⚡
🧚‍♀️◦ *ᴄᴏɴᴛᴀᴄᴛ* : https://wa.me/94742274855 ⚡

╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌

> *ʜɪ , ʙᴇғᴏʀᴇ ɢᴏɪɴɢ ᴛᴏ ᴛʜᴇ ғᴇᴀᴛᴜʀᴇs ᴍᴇɴᴜ, ᴘʟᴇᴀsᴇ ʀᴇᴀᴅ ᴛʜᴇ ʀᴜʟᴇs ғᴏʀ ᴜsɪɴɢ ᴛʜᴇ ʙᴏᴛ* 

*😼𝟷. sᴘᴀᴍ ʙᴏᴛs ᴀʀᴇ ᴘʀᴏʜɪʙɪᴛᴇᴅ.⚡*
*😼𝟸. ᴄᴀʟʟɪɴɢ ʙᴏᴛs ɪs ᴘʀᴏʜɪʙɪᴛᴇᴅ.⚡*
*😼𝟹. ᴄᴀʟʟɪɴɢ ᴏᴡɴᴇʀ ɴᴜᴍʙᴇʀ ɪs ᴘʀᴏʜɪʙɪᴛᴇᴅ.⚡*
*😼𝟺. sᴘᴀᴍ ᴛᴏ ɴᴏ ᴏᴡɴᴇʀ ɪs ᴘʀᴏʜɪʙɪᴛᴇᴅ.⚡*

╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌

*🪄🪀✨...ආයුබෝවන් බ්‍රෝ, අනාගත මෙනුව වෙත යාමට පෙර, කරුණාකර බොට් භාවිතා කිරීමේ නීති කියවන්න...✨🤖⚠️*

𝟷. *_🔱Spam Bots තහනම්.❌_*
𝟸. *_🔱Calling Bots තහනම්.❌_*
𝟹. *_🔱Calling Owner Number තහනම්.❌_*
𝟺. *_🔱හිමිකරුට Spam ගැසීම තහනම්.❌_*

╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌

*💠සම්පූර්ණ මෙනුව පෙන්වීමට _.allmenu_ ලෙස ටයිප් කරන්න...✨🤖♥️*

*💠ඔබට සත්කාරක අරමුණු සඳහා කුලියට ගැනීමට අවශ්‍ය නම්, _.owner_ ලෙස ටයිප් කරන්න... [බොට් නොවේ]*✨🤖♥️

_ɴᴏᴛᴇ: ɪғ ʏᴏᴜ ᴅᴏɴ'ᴛ ᴋɴᴏᴡ ʜᴏᴡ ᴛᴏ ᴜsᴇ ᴛʜᴇ ʙᴏᴛ, ʏᴏᴜ ᴄᴀɴ ᴛʏᴘᴇ .ᴏᴡɴᴇʀ_

*🔱සම්පූර්ණ මෙනුව පෙන්වීමට, _.allmenu_ ලෙස ටයිප් කරන්න...🪀✨🤖*


> ⚡𝐁𝐲 𝐎𝐰𝐧𝐞𝐫 - : *©ᴍᴀɴᴜʟ ᴏꜰꜰɪᴄɪᴀʟ*💗
`

await conn.sendMessage(from, { audio: { url: voice.menu }, mimetype: 'audio/mp4', ptt: true }, { quoted: mek })

return await conn.sendMessage(from,{image: {url: config.MENU_IMG},caption: tex},{quoted: mek})
}catch(e){
console.log(e)
reply(`${e}`)
}
})

//===========ᴀʟʟᴍᴇɴᴜ========

cmd({
    pattern: "allmenu",
    react: "💗",
    alias: ["list","commands"],
    desc: "Get bot\'s command list.",
    category: "main",
    use: '.menu',
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
const voice = {
    menu: 'media/media_menu.mp3'
}

let tex = `
> 🧚‍♀️𝗠𝗔𝗡𝗨-𝗠𝗗 𝗕𝗢𝗧 𝗔𝗟𝗟 𝗠𝗘𝗡𝗨💗

🧚‍♀️◦ *ɴᴀᴍᴇ ʙᴏᴛ* : ᴍᴀɴᴜ-ᴍᴅ⚡
🧚‍♀️◦ *ᴄʀᴇᴀᴛᴏʀ* : ᴍᴀɴᴜʟ ᴏꜰꜰɪᴄɪᴀʟ⚡
🧚‍♀️◦ *ʙᴏᴛ ᴜꜱᴇʀ* :${pushname}⚡
🧚‍♀️◦ *ᴜᴘᴛɪᴍᴇ* : ${runtime(process.uptime())}⚡
🧚‍♀️◦ *ᴠᴇʀsɪᴏɴs* : 7.0.0 (ᴀᴅᴅᴇᴅ ʜɪᴅᴅᴇɴ ғᴇᴀᴜᴛᴜʀᴇs)⚡
🧚‍♀️◦ *ᴛʏᴘᴇ sᴄʀɪᴘᴛ* : ᴘʟᴜɢɪɴs⚡
🧚‍♀️◦ *ᴊᴏɪɴ ᴍʏ ɢʀᴏᴜᴘ* :  https://whatsapp.com/channel/0029VaN1XMn2ZjCsu9eZQP3R ⚡
🧚‍♀️◦ *ᴄᴏɴᴛᴀᴄᴛ* : https://wa.me/94742274855 ⚡

*┌ 乂📥 ＤＯＷＮＬＯＡＤＥＲ📥 乂*
*│◦ .ғʙ <ᴜʀʟ>*
*│◦ .ɪɢ <ᴜʀʟ>*
*│◦ .ɢᴅʀɪᴠᴇ <ᴜʀʟ>*
*│◦ .ᴛᴡɪᴛᴛᴇʀ <ᴜʀʟ>*
*│◦ .ᴛɪᴋᴛᴏᴋ <ᴜʀʟ>*
*│◦ .ᴍᴇᴅɪᴀғɪʀᴇ <ᴜʀʟ>*
*│◦ .ꜱᴏɴɢ <ϙᴜᴇʀʏ>*
*│◦ .ꜱᴏɴɢ2 <ϙᴜᴇʀʏ>*
*│◦ .ᴠɪᴅᴇᴏ <ϙᴜᴇʀʏ>*
*└ ◦ .ᴠɪᴅᴇᴏ2 <ϙᴜᴇʀʏ>*

*┌ 乂 🔎 S E A R C H 🔍乂*
*│◦ .ʏᴛꜱ  <ᴛᴇxᴛ>*
*│◦ .ʏᴛꜱ1 <ᴛᴇxᴛ>*
*│◦ .ᴡɪᴋɪ <ᴛᴇxᴛ>*
*│◦ .ᴅᴏɢ*
*└ ◦ .ᴀɴɪᴍᴇɢɪʀʟ*

*┌ 乂 🧠 ＡＩ 🧠*
*│◦  .ᴀɪ <ᴛᴇxᴛ>*
*│◦ .ɢᴘᴛ <ᴛᴇxᴛ>*
*│◦ .ʟᴀᴍᴅᴀ <ᴛᴇxᴛ>*
*│◦ .ʀᴇᴍɪɴɪ <ᴛᴇxᴛ>*
*└ ◦ .ʟᴀʟᴀʟᴀɴᴅ <ᴛᴇxᴛ>*


*┌ 乂 👨‍💻ＯＷＮＥＲ 👨‍💻*
*│◦ .ʙᴀɴᴄʜᴀᴛ*
*│◦ .ʙᴀɴ @ᴜsᴇʀ*
*│◦ .ʀᴇꜱᴛᴀʀᴛ*
*│◦ .ᴜɴʙᴀɴ*
*│◦ .ᴜɴʙᴀɴ @ᴜsᴇʀ*
*│◦ .ʙʟᴏᴄᴋ*
*│◦ .ᴜɴʙʟᴏᴄᴋ*
*│◦ .ᴊɪᴅ*
*│◦ .ɢᴊɪᴅꜱ*
*│◦ .ꜱʜᴜᴛᴅᴏᴡɴ*
*│◦ .ᴄʟᴇᴀʀᴄʜᴀᴛꜱ*
*│◦ .ʙʀᴏᴀᴅᴄᴀꜱᴛ*
*│◦ .sᴇᴛᴘᴘ <ʀᴇᴘʟʏ ᴡɪᴛʜ ᴘʜᴏᴛᴏ>*
*└ ◦ .sᴇᴛʙɪᴏ*

*┌ 乂 👥 ＧＲＯＵＰ 👥*
*│◦ .ᴅᴇʟ <ʀᴇᴘʟʏ ᴛᴏ ᴛʜᴇ ᴍsɢ ᴜ ᴡᴀɴᴛ ᴛᴏ ᴅᴇʟᴇᴛᴇ>*
*│◦ .ᴀᴅᴅ*
*│◦ .sᴇᴛᴅᴇsᴄ <ᴛᴇxᴛ>*
*│◦ .ᴘʀᴏᴍᴏᴛᴇ*
*│◦ .ᴅᴇᴍᴏᴛᴇ*
*│◦ .ʜɪᴅᴇᴛᴀɢ*
*│◦ .ᴛᴀɢᴀʟʟ*
*│◦ .ᴛᴀɢᴀᴅᴍɪɴ*
*│◦ .ɪɴᴠɪᴛᴇ*
*│◦ .ᴋɪᴄᴋ*
*│◦ .ʟᴇᴀᴠᴇ*
*└ ◦ .ʟɪɴᴋ*

*┌ 乂 📃 ＩＮＦＯ 📃*
*│◦ .ᴍᴇɴᴜ*
*│◦ .ᴀʟʟᴍᴇɴᴜ*
*│◦ .ꜱᴄʀɪᴘᴛ*
*│◦ .ᴘɪɴɢ*
*│◦ .ꜱʏꜱᴛᴇᴍ*
*│◦ .ʀᴜɴᴛɪᴍᴇ*
*└ ◦ .ᴀʟɪᴠᴇ*

*┌ 乂 🔄ＣＯＮＶＥＲＴＥＲ 🔄*
*│◦ .ᴛᴏᴍᴘ3*
*│◦ .ᴛᴏᴜʀʟ*
*│◦ .ᴄᴏɴᴠᴇʀᴛ*
*└ ◦ .sᴛɪᴄᴋᴇʀ*

*┌ 乂 ♦️ O Ｔ H E Ｒ ♦️*
*│◦ .ᴊᴏᴋᴇ*
*│◦ .ꜱᴜᴘᴘᴏʀᴛ*
*│◦ .ꜰᴀᴄᴛ*
*│◦ .Qᴜᴏᴛᴇ*
*│◦ .ʜᴀᴄᴋ*
*│◦ .ᴅᴇꜰɪɴᴇ*
*│◦ .ᴀʙᴏᴜᴛ*
*│◦ .ᴏᴡɴᴇʀ*
*│◦ .ɴᴇᴡꜱ*
*│◦ .ᴡᴇᴀᴛʜᴇʀ*
*│◦ .ɢᴘᴀꜱꜱ*
*│◦ .ꜰᴀᴄᴛ*
*└ ◦ .ɢɪᴛʜᴜʙꜱᴛᴀʟᴋ*

> *⚖️𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 - : ©𝐌𝐫 𝐂𝐲𝐛𝐞𝐫 𝐌𝐚𝐧𝐮𝐥 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 2024💗*
`
await conn.sendMessage(from, { audio: { url: voice.menu }, mimetype: 'audio/mp4', ptt: true }, { quoted: mek })

return await conn.sendMessage(from,{image: {url: config.MENU_IMG},caption: tex},{quoted: mek})
}catch(e){
console.log(e)
reply(`${e}`)
}
})

//============ᴏᴡɴᴇʀ================

cmd({
    pattern: "owner",
    react: "👨‍💻",
    alias: ["dev","createor","developer"],
    desc: "Get bot\'s command list.",
    category: "main",
    use: '.menu',
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
const voice = {
    owner: 'media/media_menu.mp3'
}

let tex = `
*🪄Hello* ${pushname},

*🧚‍♀️𝐈'𝐦 𝐌𝐚𝐧𝐮-𝐌𝐃 𝐖𝐡𝐚𝐭𝐬𝐀𝐩𝐩 𝐁𝐨𝐭💗*

> 👨‍💻 *MY 𝗢𝗪𝗡𝗘𝗥 𝗜𝗡𝗙𝗢* ⚖️

*⚡ηαмє -: ᴍᴀɴᴜʟ ᴏꜰꜰɪᴄɪᴀʟ*
*⚡αgє -: 16*
*⚡ωєв* -: https://manulofficial.vercel.app/
*⚡ηυмвєя* -: +94742274855
*⚡уσυтυвє* -: https://www.youtube.com/@ManulOfficialTech

> ᴘᴏᴡᴇʀᴇᴅ ʙʏ -: *⚡©ᴍᴀɴᴜʟ ᴏꜰꜰɪᴄɪᴀʟ 2024💗*

`
await conn.sendMessage(from, { audio: { url: voice.owner }, mimetype: 'audio/mp4', ptt: true }, { quoted: mek })

return await conn.sendMessage(from,{image: {url: config.MENU_IMG},caption: tex},{quoted: mek})
}catch(e){
console.log(e)
reply(`${e}`)
}
})

cmd({
    pattern: "sc",
    react: "📔",
    alias: ["script"],
    desc: "Get bot\'s script list.",
    category: "main",
    use: '.script',
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
let tex = `
> 🧚‍♀️𝗛𝗲𝘆👋 *${pushname}* 𝗜'𝗺 𝗠𝗮𝗻𝘂 𝗠𝗗 𝗪𝗵𝗮𝘁𝘀𝗔𝗽𝗽 𝗕𝗼𝘁⚡💗

*${pushname}* *𝐀𝐫𝐞 𝐘𝐨𝐮 𝐖𝐚𝐧𝐭 𝐒𝐜𝐫𝐢𝐩𝐭???💗* 

*👨‍💻ρℓєαѕє ¢σηтα¢т му σωηєя⚖️*
 
                   *⚜️ℝ𝕦𝕝𝕖𝕤🔱*

*😼⚜️𝟷. sᴘᴀᴍ ʙᴏᴛs ᴀʀᴇ ᴘʀᴏʜɪʙɪᴛᴇᴅ.⚡🔱🦠*
*😼⚜️𝟸. ᴄᴀʟʟɪɴɢ ʙᴏᴛs ɪs ᴘʀᴏʜɪʙɪᴛᴇᴅ.⚡🔱☎️*
*😼⚜️𝟹. ᴄᴀʟʟɪɴɢ ᴏᴡɴᴇʀ ɴᴜᴍʙᴇʀ ɪs ᴘʀᴏʜɪʙɪᴛᴇᴅ.⚡🔱☎️*
*😼⚜️𝟺. sᴘᴀᴍ ᴛᴏ ɴᴏ ᴏᴡɴᴇʀ ɪs ᴘʀᴏʜɪʙɪᴛᴇᴅ.⚡🔱🦠*

*ωнαтѕαρρ*- : +94742274855
*ωєвѕιтє* - : https://manulofficial.vercel.app/
*уσυтυвє* - : https://www.youtube.com/@ManulOfficialTech

> *⚖️°𝙱𝚢 © 𝙼𝚁 𝙼𝚊𝚗𝚞𝚕 𝙾𝚏𝚏𝚒𝚌𝚒𝚊𝚕 •2024•* 💗
`
return await conn.sendMessage(from,{image: {url: config.MENU_IMG},caption: tex},{quoted: mek})
}catch(e){
console.log(e)
reply(`${e}`)
}
})

//==========restart========

cmd({
    pattern: "restart",
    react: "♻",
    desc: "restart the bot",
    category: "owner",
    filename: __filename
},
async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
if(!isOwner) return
const {exec} = require("child_process")
reply("restarting...")
await sleep(1500)
exec("pm2 restart all")
}catch(e){
console.log(e)
reply(`${e}`)
}
})

//=======oo======

cmd({
    pattern: "esananews",
    react: '🎙️',
    desc: "To see esana news",
    category: "search",
    use: '.sirasa',
    filename: __filename
},
async(conn, mek, m,{from, l, prefix, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{
    const latst = await api.latest_id();
            const nws = latst.results.news_id
            let nn = q || nws
            const ress = await api.news(nn);
            const res = ress.results;

            const txt2 = await conn.sendMessage(from, {image: 
	    {url: res.COVER},caption: `\n*┃◉* *⇨ ᴛɪᴛᴇʟ :*
 ${res.TITLE}\n\n*┃◉* *⇨ ᴅᴀᴛᴇ :*
 ${res.PUBLISHED}\n\n*┃◉* *⇨ ᴜʀʟ :*
 ${res.URL}\n\n*┃◉* *⇨ Description :*
 ${res.DESCRIPTION}\n\n*𝙿𝙾𝚆𝙴𝚁𝙳 𝙱𝚈 ©ᴍᴀɴᴜʟ ᴏꜰꜰɪᴄɪᴀʟ*\n\n`},
			{ quoted: mek });
await conn.sendMessage(from, { react: { text: `✅`, key: mek.key }}) 
} catch (e) {
reply()
l(e)
}
})       


cmd({
    pattern: "slsub",
    react: "📃",
    alias: ["srisub"],
    desc: "Search Sinhala Subtitles  from Web Site",
    category: "download",
    use: '.slsub',
    filename: __filename
},
async(conn, mek, m,{from, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isCreator ,isDev, isAdmins, reply}) => {
try{
if (!q) return reply("❗ *Please enter movie name to download Subtitles*")
const duka = await subsearch(q)
const latest = await subdl(duka.results[0].link)
const maru =`*MANU-MD SINHALA SUB DOWNLOADER*

📊 *Movie Title - ${latest.results.title}*

🔒 Creator - ${latest.results.creater}

🖇️ _Link_ - ${duka.results[0].link}

`
  await conn.sendMessage(from,{image:{url: latest.results.img },caption: maru + "*ᴍᴀɴᴜ-ᴍᴅ ᴡʜᴀᴛꜱᴀᴘᴘ ᴜꜱᴇʀ ʙᴏᴛ*\n*ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴍᴀɴᴜʟ ᴏꜰꜰɪᴄɪᴀʟ*" },{quoted:mek })
  await conn.sendMessage(from, { document : { url : latest.results.dl_link  }  ,caption: latest.results.title ,mimetype: 'application/zip', fileName: `${latest.results.title}.zip` }, { quoted: mek })
} catch (e) {
reply('🚫 *Error Accurated !!*\n\n' + e )
l(e)
}
})

cmd({
    pattern: "slsubsearch",
    react: "🔎",
    desc: "Search All Subtitles  from Web Site",
    category: "search",
    use: '.technewsall',
    filename: __filename
},
async(conn, mek, m,{from, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isCreator ,isDev, isAdmins, reply}) => {
try{
if (!q) return reply("❗ *Please enter movie name to Search Subtitles*")
const vid = await subsearch(q)
    let yt = '\n❍⚯────────────────────⚯❍\n        🌐  *𝚂𝙻 𝚂𝚄𝙱 𝚂𝙴𝙰𝚁𝙲𝙷 𝙻𝙸𝚂𝚃*  🌐\n ⚡ *ᴍᴀɴᴜʟ ᴏꜰꜰɪᴄɪᴀʟ ꜱᴜʙᴛɪᴛʟᴇ ꜱᴇᴀʀᴄʜᴇʀ* ⚡\n❍⚯────────────────────⚯❍\n\n\n'
    for (let i of vid.results ) {
        yt += `📃 *${i.no} - ${i.title}*\n🔗 _Link : ${i.link}_ \n\n\n`
    }
 await conn.sendMessage(from,{image:{url: "https://telegra.ph/file/33e5f1bfd36ea02f8b062.jpg" },caption: yt + "*ᴍᴀɴᴜ-ᴍᴅ ᴡʜᴀᴛꜱᴀᴘᴘ ᴜꜱᴇʀ ʙᴏᴛ*\n*ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴍᴀɴᴜʟ ᴏꜰꜰɪᴄɪᴀʟ*" },{quoted:mek })
} catch (e) {
reply('⛔ *Error accurated !!*\n\n' + e )
l(e)
}
})

cmd({
    pattern: "subdlfromlink",
    react: "📃",
    desc: "Download subtitles from Web Sites",
    category: "download",
    use: '.subdlfromlink',
    filename: __filename
},
async(conn, mek, m,{from, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isCreator ,isDev, isAdmins, reply}) => {
try{
if (!q) return reply("❗ Please enter movie Link to download Subtitles*")
if(!q.includes('baiscope')) return reply('🚫 *Please enter Valid Movie url*')
 const latest = await subdl(q)
const maru =`*MANU-MD SL SUBTITLES DOWNLOADER*

📊 *Movie title - ${latest.results.title}*

🔒 Creator - ${latest.results.creater}

🖇️ _Link_ - ${q}

*ᴍᴀɴᴜ-ᴍᴅ*
*ᴀʟʟ ʀɪɢʜᴛ ʀᴇꜱᴇʀᴠᴇᴅ - ʙʏ ᴍᴀɴᴜʟ ᴏꜰꜰɪᴄɪᴀʟ*`
 await conn.sendMessage(from , { text: maru }, { quoted: mek } )
   await conn.sendMessage(from, { document : { url : latest.results.dl_link  }  ,caption: latest.results.title ,mimetype: 'application/zip', fileName: `${latest.results.title}.zip` }, { quoted: mek })
} catch (e) {
reply('🚫 *Error Accurated !!*\n\n' + e )
l(e)
}
})
